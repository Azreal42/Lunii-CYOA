import json
import os
import shutil
from collections.abc import Iterable
from pathlib import Path
from typing import Dict, List, Optional, TypedDict
from uuid import UUID

import requests

from pkg.api.constants import (
    CACHE_DIR,
    CFG_DIR,
    FILE_OFFICIAL_DB,
    FILE_THIRD_PARTY_DB,
    OFFICIAL_DB_URL,
    OFFICIAL_TOKEN_URL,
    STORY_TRANSCODING_SUPPORTED,
)

STORY_UNKNOWN  = "Unknown story (maybe a User created story)..."
DESC_NOT_FOUND = "No description found."

# https://server-data-prod.lunii.com/v2/packs
class LocalizedInfo(TypedDict, total=False):
    title: str
    description: str
    image: Dict[str, str]


class StoryDbEntry(TypedDict, total=False):
    uuid: str
    title: str
    description: str
    locales_available: Dict[str, str]
    localized_infos: Dict[str, LocalizedInfo]


StoryDb = Dict[str, StoryDbEntry]


DB_OFFICIAL: StoryDb = {}
DB_THIRD_PARTY: StoryDb = {}
UUID_DB: StoryDb = DB_OFFICIAL  # backward compatibility for older tests/tools

NODE_SIZE = 0x2C
NI_HEADER_SIZE = 0x200

FILE_THUMB = "_thumbnail.png"
FILE_META  = "_metadata.json"
FILE_UUID  = "uuid.bin"
FILE_STUDIO_JSON  = "story.json"
FILE_STUDIO_THUMB = "thumbnail.png"

class StudioStory:
    def __init__(self, story_json: Optional[dict] = None):
        self.format_version: str | int = 0
        self.pack_version: int = 0
        self.title: str = ""
        self.description: str = ""
        self.factory_pack = 1
        self.uuid: Optional[UUID] = None

        self.js_snodes: Optional[list[dict]] = None
        self.js_anodes: Optional[list[dict]] = None
        self.ri: dict[str, tuple[str, int]] = {}
        self.si: dict[str, tuple[str, int]] = {}
        self.li: List[int] = list()

        # depends on ffmpeg presence on host system
        self.compatible = False

        if story_json:
            self.load(story_json)

    @property
    def name(self) -> str:
        return self.title

    @property
    def str_uuid(self) -> Optional[str]:
        if self.uuid:
            return str(self.uuid).upper()
        return None

    @property
    def short_uuid(self) -> Optional[str]:
        if self.uuid:
            return self.uuid.hex[24:].upper()
        return None
    
    def load(self, story_json: dict) -> None:
        self.format_version = story_json.get('format')
        self.pack_version = story_json.get('version')
        self.title = story_json.get('title')
        self.description = story_json.get('description')

        # looping stage nodes
        self.js_snodes = story_json.get('stageNodes', [])
        for snode in self.js_snodes:
            n_uuid = UUID(snode.get('uuid'))
            if not self.uuid:
                self.uuid = n_uuid

            image = snode.get('image')
            if image:
                if image not in self.ri:
                    normalized_name = os.path.splitext(image)[0]
                    normalized_name = normalized_name[-8:].upper()
                    self.ri[image] = (normalized_name, len(self.ri))

            audio = snode.get('audio')
            if audio:
                if not STORY_TRANSCODING_SUPPORTED and not audio.lower().endswith('.mp3'):
                    self.compatible = False
                    return

                if audio not in self.si:
                    normalized_name = os.path.splitext(audio)[0]
                    normalized_name = normalized_name[-8:].upper()
                    self.si[audio] = (normalized_name, len(self.si))

        # looping action nodes
        absolute_index = 0
        self.js_anodes = story_json.get('actionNodes', [])
        for anode in self.js_anodes:
            anode["global_index"] = absolute_index
            absolute_index += len(anode.get("options"))
            for option in anode.get("options"):
                option_index = next((index for index, snode in enumerate(self.js_snodes) if snode.get('uuid') == option), -1)
                self.li.append(option_index)

        self.compatible = True

    def get_ri_data(self) -> bytes:
        data_ri = ""
        for file in self.ri:
            data_ri += f"000\\{self.ri[file][0]}"
        return data_ri.encode('utf-8')
    
    def get_si_data(self) -> bytes:
        data_si = ""
        for file in self.si:
            data_si += f"000\\{self.si[file][0]}"
        return data_si.encode('utf-8')
    
    def get_ni_data(self) -> bytes:
        if self.js_snodes is None or self.js_anodes is None:
            return b""

        ni_buffer = b""

        # header section
        ni_buffer += int(str(self.format_version)[1:]).to_bytes(2, byteorder='little')
        ni_buffer += int(self.pack_version).to_bytes(2, byteorder='little')
        ni_buffer += int(NI_HEADER_SIZE).to_bytes(4, byteorder='little')
        ni_buffer += int(NODE_SIZE).to_bytes(4, byteorder='little')
        ni_buffer += len(self.js_snodes).to_bytes(4, byteorder='little')
        ni_buffer += len(self.ri).to_bytes(4, byteorder='little')
        ni_buffer += len(self.si).to_bytes(4, byteorder='little')
        ni_buffer += int(1).to_bytes(1, byteorder='little')

        # padding the header with 00
        ni_buffer += b"\x00" * (NI_HEADER_SIZE - len(ni_buffer))

        # node section
        for snode in self.js_snodes:
            current_node = b""

            # image / audio for nodes
            ri_index = -1
            si_index = -1
            if snode.get('image') in self.ri:
                ri_index = self.ri[snode.get('image')][1]
            if snode.get('audio') in self.si:
                si_index = self.si[snode.get('audio')][1]
            current_node += ri_index.to_bytes(4, byteorder='little', signed=True)
            current_node += si_index.to_bytes(4, byteorder='little', signed=True)
            
            # ok transition
            trans_node = snode.get("okTransition")
            if trans_node:
                # looking for action node
                anode_uuid = trans_node.get("actionNode")
                anode = next((one_node for one_node in self.js_anodes if one_node.get('id') == anode_uuid), -1)
                li_index = anode.get("global_index")
                # transition settings
                current_node += li_index.to_bytes(4, byteorder='little', signed=True)
                current_node += len(anode.get('options')).to_bytes(4, byteorder='little', signed=True)
                current_node += trans_node.get('optionIndex').to_bytes(4, byteorder='little', signed=True)
            else:
                current_node += b"\xFF\xFF\xFF\xFF" * 3

            # home transition
            trans_node = snode.get("homeTransition")
            if trans_node:
                # looking for action node
                anode_uuid = trans_node.get("actionNode")
                anode = next((one_node for one_node in self.js_anodes if one_node.get('id') == anode_uuid), -1)
                li_index = anode.get("global_index")
                # transition settings
                current_node += li_index.to_bytes(4, byteorder='little', signed=True)
                current_node += len(anode.get('options')).to_bytes(4, byteorder='little', signed=True)
                current_node += trans_node.get('optionIndex').to_bytes(4, byteorder='little', signed=True)
            else:
                current_node += b"\xFF\xFF\xFF\xFF" * 3

            # control section
            controls = snode.get("controlSettings")
            if controls:
                current_node += controls.get("wheel").to_bytes(2, byteorder="little")
                current_node += controls.get("ok").to_bytes(2, byteorder="little")
                current_node += controls.get("home").to_bytes(2, byteorder="little")
                current_node += controls.get("pause").to_bytes(2, byteorder="little")
                current_node += controls.get("autoplay").to_bytes(2, byteorder="little")
                current_node += b"\x00\x00"

            # FINAL : adding current node to list
            ni_buffer += current_node
            ni_buffer += b"\xAA" * (NODE_SIZE - len(current_node))

        return ni_buffer

    def get_li_data(self) -> bytes:
        li_buffer = b""

        # parsing list node index
        for index in self.li:
            # Write index as signed 4-byte integer (little endian)
            li_buffer += index.to_bytes(4, byteorder='little', signed=True)

        # adding extra padding for small stories
        while len(li_buffer) < 8:
            li_buffer += b"\x00"

        return li_buffer

    def write_bt(self, path_ni: str) -> None:
        return


def story_load_db(reload: bool = False) -> bool:
    global DB_OFFICIAL
    global DB_THIRD_PARTY
    retVal = True

    # fetching db if necessary
    if not os.path.isfile(FILE_OFFICIAL_DB) or reload:
        # creating dir if not there
        if not os.path.isdir(CFG_DIR):
            Path(CFG_DIR).mkdir(parents=True, exist_ok=True)

        try:
            # Set the timeout for the request
            token_resp = requests.get(OFFICIAL_TOKEN_URL, timeout=30)
            if token_resp.status_code == 200:
                auth_token = token_resp.json()['response']['token']['server']

                req_headers = {"Application-Sender": "luniistore_desktop",
                               "Accept": "application/json",
                               'X-AUTH-TOKEN': auth_token,
                              }

                response = requests.get(OFFICIAL_DB_URL, headers=req_headers, timeout=30)
                if response.status_code == 200:
                    # Load image from bytes
                    j_resp = json.loads(response.content)
                    with (open(FILE_OFFICIAL_DB, "w") as fp):
                        db = j_resp.get('response')
                        json.dump(db, fp)

        except (requests.exceptions.Timeout, requests.exceptions.RequestException, requests.exceptions.ConnectionError):
            retVal = False

    # trying to load official DB
    if os.path.isfile(FILE_OFFICIAL_DB):
        try:
            with open(FILE_OFFICIAL_DB, encoding='utf-8') as fp_db:
                db_stories = json.load(fp_db)
                DB_OFFICIAL = {db_stories[key]["uuid"].upper(): value for (key, value) in db_stories.items()}
        except (json.JSONDecodeError, OSError):
            db = Path(FILE_OFFICIAL_DB)
            db.unlink(FILE_OFFICIAL_DB)

    # trying to load third-party DB
    if not os.path.isfile(FILE_THIRD_PARTY_DB):
        # no local unofficial DB, creating the one from resource
        project_root = Path(__file__).resolve().parents[3]
        file = os.path.join(project_root, "res", "unofficial.json")
        # Copy the file
        shutil.copyfile(file, FILE_THIRD_PARTY_DB)

    # there should be an unofficial DB
    if os.path.isfile(FILE_THIRD_PARTY_DB):
        try:
            with open(FILE_THIRD_PARTY_DB, encoding='utf-8') as fp_db:
                db_stories = json.load(fp_db)
                DB_THIRD_PARTY = {db_stories[key]["uuid"].upper(): value for (key, value) in db_stories.items()}
        except (json.JSONDecodeError, OSError):
            db = Path(FILE_THIRD_PARTY_DB)
            db.unlink(FILE_THIRD_PARTY_DB)

    return retVal


def thirdparty_db_add_thumb(uuid: UUID, image_data: bytes) -> None:
    # creating cache dir if necessary
    if not os.path.isdir(CACHE_DIR):
        Path(CACHE_DIR).mkdir(parents=True, exist_ok=True)

    # checking if present in cache
    one_uuid = str(uuid).upper()
    res_file = os.path.join(CACHE_DIR, one_uuid)

    if not os.path.isfile(res_file):
        # write data to file
        with open(res_file, "wb") as fp:
            fp.write(image_data)


def thirdparty_db_add_story(uuid: UUID, title: str, desc: str) -> None:
    db_stories = dict()

    # trying to load third-party DB
    if os.path.isfile(FILE_THIRD_PARTY_DB):
        try:
            with open(FILE_THIRD_PARTY_DB, encoding='utf-8') as fp_db:
                db_stories = json.load(fp_db)
        except (json.JSONDecodeError, OSError):
            db = Path(FILE_THIRD_PARTY_DB)
            db.unlink(FILE_THIRD_PARTY_DB)

    # creating new entry
    db_stories[uuid.hex] = {'uuid': str(uuid), 'title': title, 'description': desc}

    # saving updated db
    with open(FILE_THIRD_PARTY_DB, "w", encoding='utf-8') as fp_db:
        json.dump(db_stories, fp_db)

    # reloading DBs
    story_load_db()


def _uuid_match(uuid: UUID, key_part: str) -> bool:
    uuid = uuid.hex.upper()
    key_part = key_part.replace("-", "").upper()

    return key_part in uuid


class Story:
    def __init__(self, uuid: UUID, hidden: bool = False, size: int = -1):
        self.uuid: UUID = uuid
        self.size = size
        self.hidden = hidden

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, UUID):
            return False
        return self.uuid == __value

    @property
    def str_uuid(self) -> str:
        return str(self.uuid).upper()

    @property
    def short_uuid(self) -> str:
        return self.uuid.hex[24:].upper()

    @property
    def name(self) -> str:
        one_uuid = str(self.uuid).upper()

        for db in [DB_OFFICIAL, DB_THIRD_PARTY]:
            # checking current db
            if one_uuid in db:
                entry = db[one_uuid]
                if entry.get("locales_available") and entry.get("localized_infos"):
                    locale = next(iter(entry["locales_available"]))
                    title = entry["localized_infos"][locale].get("title")
                    if title:
                        return title
                else:
                    title = entry.get("title")
                    if title:
                        return title

        return STORY_UNKNOWN

    @property
    def desc(self) -> str:
        one_uuid = str(self.uuid).upper()

        for db in [DB_OFFICIAL, DB_THIRD_PARTY]:
            # checking current db
            if one_uuid in db:
                entry = db[one_uuid]
                if entry.get("locales_available") and entry.get("localized_infos"):
                    locale = next(iter(entry["locales_available"]))
                    desc: str | None = entry["localized_infos"][locale].get("description")
                    if desc:
                        # removing html parts
                        while desc.lstrip().startswith("<"):
                            pos = desc.find(">")
                            desc = desc[pos+1:].lstrip()
                        return desc
                else:
                    desc = entry.get("description")
                    if desc:
                        return desc

        return DESC_NOT_FOUND

    def get_picture(self, reload: bool = False) -> Optional[bytes]:
        image_data: Optional[bytes] = None

        # creating cache dir if necessary
        if not os.path.isdir(CACHE_DIR):
            Path(CACHE_DIR).mkdir(parents=True, exist_ok=True)

        # checking if present in cache
        one_uuid = str(self.uuid).upper()
        res_file = os.path.join(CACHE_DIR, one_uuid)

        if reload or not os.path.isfile(res_file):
            # downloading the image to a file
            one_story_imageURL = self.picture_url()
            if one_story_imageURL:
                try:
                    response = requests.get(one_story_imageURL, timeout=2)
                    if response.status_code == 200:
                        image_data = response.content
                        with open(res_file, "wb") as fp:
                            fp.write(image_data)
                except requests.exceptions.Timeout:
                    pass
                except requests.exceptions.RequestException:
                    pass

        if not image_data and os.path.isfile(res_file):
            with open(res_file, "rb") as fp:
                image_data = fp.read()

        return image_data

    def picture_url(self) -> Optional[str]:
        one_uuid = str(self.uuid).upper()

        if one_uuid in DB_OFFICIAL:
            entry = DB_OFFICIAL[one_uuid]
            locales_available = entry.get("locales_available", {})
            if locales_available:
                locale = next(iter(locales_available))
                localized = entry.get("localized_infos", {})
                image = localized.get(locale, {}).get("image")
                if image and image.get("image_url"):
                    return "https://storage.googleapis.com/lunii-data-prod" + image.get("image_url")
        return None

    def get_meta(self) -> Optional[str]:
        one_uuid = self.str_uuid

        if one_uuid in DB_THIRD_PARTY:
            meta = DB_THIRD_PARTY[one_uuid]
            return json.dumps(meta)

        return None

    def is_official(self) -> bool:
        return str(self.uuid).upper() in DB_OFFICIAL


class StoryList(List[Story]):
    def __init__(self):
        super().__init__()

    def __contains__(self, key_part: object) -> bool:
        for one_story in self:
            target_uuid = one_story.uuid if isinstance(one_story, Story) else one_story
            if isinstance(target_uuid, UUID) and _uuid_match(target_uuid, str(key_part)):
                return True
        return False

    def get_story(self, key_part: str) -> Optional[Story]:
        for one_story in self:
            if _uuid_match(one_story.uuid, str(key_part)):
                return one_story
        return None

    def matching_stories(self, short_uuid: str) -> List[Story]:
        return [one_story for one_story in self if _uuid_match(one_story.uuid, short_uuid)]

    def full_uuid(self, key_part: str) -> List[UUID]:
        return [one_story.uuid for one_story in self if _uuid_match(one_story.uuid, key_part)]


def story_is_studio(contents: Iterable[str]) -> bool:
    for file in contents:
        for studio_pattern in [FILE_STUDIO_JSON, FILE_STUDIO_THUMB, "assets/"]:
            if studio_pattern in file:
                return True

    return False


def story_is_lunii(contents: Iterable[str]) -> bool:
    return all(any(file.endswith(pattern) for file in contents) for pattern in ["ri", "si", "li", "ni"])

